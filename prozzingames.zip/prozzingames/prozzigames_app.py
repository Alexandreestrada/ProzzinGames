# ProzziGames - Single-file Tkinter GUI app

# Structure: 12 windows (frames) as requested.
# - Uses SQLite for persistence (users, games, orders).
# - Creates placeholder images if not provided.
# - Differentiates client and admin users by 'is_admin' flag.
# - Run: python prozzigames_app.py

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
from pathlib import Path
from PIL import Image, ImageTk
import os
import datetime

DB_PATH = Path("prozzigames.db")
IMAGES_DIR = Path("images")
IMAGES_DIR.mkdir(exist_ok=True)

# ---------- Database helpers ----------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # users: id, username, password, is_admin (0/1), fullname
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE,
                    password TEXT,
                    is_admin INTEGER DEFAULT 0,
                    fullname TEXT
                )''')
    # games: id, title, price, stock, image
    c.execute('''CREATE TABLE IF NOT EXISTS games (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    price REAL,
                    stock INTEGER,
                    image TEXT
                )''')
    # orders: id, user_id, items_text, total, created_at
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    items_text TEXT,
                    total REAL,
                    created_at TEXT
                )''')
    conn.commit()
    # create default admin if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE username='admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username,password,is_admin,fullname) VALUES (?,?,?,?)",
                  ("admin","admin123",1,"Admin Prozzi"))
    # create some sample games if empty
    c.execute("SELECT COUNT(*) FROM games")
    if c.fetchone()[0] == 0:
        sample = [
            ("CyberRift", 59.90, 10, "images/game1.png"),
            ("SkyFighter", 39.50, 8, "images/game2.png"),
            ("DungeonX", 29.99, 15, "images/game3.png"),
            ("RaceRush", 19.99, 20, "images/game4.png"),
            ("MystFarm", 9.99, 30, "images/game5.png"),
            ("PuzzleMind", 4.99, 50, "images/game6.png"),
        ]
        c.executemany("INSERT INTO games (title,price,stock,image) VALUES (?,?,?,?)", sample)
    conn.commit()
    conn.close()

# ---------- Simple Image loader ----------
def load_image(path, size=(180,90)):
    try:
        img = Image.open(path)
        img.thumbnail(size)
        return ImageTk.PhotoImage(img)
    except Exception:
        # placeholder
        placeholder = Image.new("RGB", size, color=(120,120,120))
        return ImageTk.PhotoImage(placeholder)

# ---------- Main Application ----------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ProzziGames")
        self.geometry("900x600")
        self.resizable(False, False)
        self.conn = sqlite3.connect(DB_PATH)
        self.current_user = None  # dict with id,username,is_admin,fullname
        # Container for frames
        container = ttk.Frame(self)
        container.pack(fill="both", expand=True)
        self.frames = {}
        # Register all frames (12 screens)
        for F in (WelcomeScreen, LoginScreen, RegisterScreen, ClientMenu, AdminMenu,
                  GamesListScreen, CartScreen, CheckoutScreen, HistoryScreen,
                  ManageGamesScreen, ManageUsersScreen, AboutScreen):
            frame = F(container, self)
            self.frames[F.__name__] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        # cart stored in memory as list of (game_id, title, price, qty)
        self.cart = []
        self.show_frame("WelcomeScreen")

    def show_frame(self, name):
        frame = self.frames[name]
        if hasattr(frame, "on_show"):
            frame.on_show()
        frame.tkraise()

    def query(self, sql, params=(), one=False):
        cur = self.conn.cursor()
        cur.execute(sql, params)
        self.conn.commit()
        if one:
            return cur.fetchone()
        return cur.fetchall()

    def logout(self):
        self.current_user = None
        self.cart = []
        self.show_frame("WelcomeScreen")

# ---------- Screens ----------

class WelcomeScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        # logo
        logo_path = IMAGES_DIR / "logo.png"
        self.logo_img = load_image(logo_path, size=(360,180))
        lbl_logo = ttk.Label(self, image=self.logo_img)
        lbl_logo.pack(pady=10)
        lbl = ttk.Label(self, text="Bem-vindo à ProzziGames!", font=("Helvetica", 20))
        lbl.pack(pady=5)
        sub = ttk.Label(self, text="Sua loja de games favorita - compre, gerencie e jogue.", font=("Helvetica", 12))
        sub.pack(pady=5)
        btn_login = ttk.Button(self, text="Entrar / Login", command=lambda: controller.show_frame("LoginScreen"))
        btn_login.pack(pady=8)
        btn_register = ttk.Button(self, text="Cadastre-se", command=lambda: controller.show_frame("RegisterScreen"))
        btn_register.pack(pady=4)
        btn_about = ttk.Button(self, text="Sobre / Contato", command=lambda: controller.show_frame("AboutScreen"))
        btn_about.pack(pady=4)
        # quick browse button
        btn_browse = ttk.Button(self, text="Ver jogos (sem login)", command=lambda: controller.show_frame("GamesListScreen"))
        btn_browse.pack(pady=8)

class LoginScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Login", font=("Helvetica", 18)).pack(pady=10)
        frm = ttk.Frame(self)
        frm.pack()
        ttk.Label(frm, text="Usuário:").grid(row=0,column=0,sticky="e")
        self.ent_user = ttk.Entry(frm)
        self.ent_user.grid(row=0,column=1)
        ttk.Label(frm, text="Senha:").grid(row=1,column=0,sticky="e")
        self.ent_pass = ttk.Entry(frm, show="*")
        self.ent_pass.grid(row=1,column=1)
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Entrar", command=self.do_login).grid(row=0,column=0,padx=5)
        ttk.Button(btn_frame, text="Voltar", command=lambda: controller.show_frame("WelcomeScreen")).grid(row=0,column=1,padx=5)

    def do_login(self):
        u = self.ent_user.get().strip()
        p = self.ent_pass.get().strip()
        if not u or not p:
            messagebox.showwarning("Dados faltando", "Informe usuário e senha.")
            return
        row = self.controller.query("SELECT id,username,is_admin,fullname FROM users WHERE username=? AND password=?", (u,p), one=True)
        if row:
            self.controller.current_user = {"id":row[0],"username":row[1],"is_admin":bool(row[2]),"fullname":row[3] or row[1]}
            if self.controller.current_user["is_admin"]:
                self.controller.show_frame("AdminMenu")
            else:
                self.controller.show_frame("ClientMenu")
        else:
            messagebox.showerror("Erro", "Usuário ou senha inválidos.")

class RegisterScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Cadastro", font=("Helvetica", 18)).pack(pady=10)
        frm = ttk.Frame(self)
        frm.pack()
        ttk.Label(frm, text="Nome completo:").grid(row=0,column=0,sticky="e")
        self.ent_name = ttk.Entry(frm, width=30); self.ent_name.grid(row=0,column=1)
        ttk.Label(frm, text="Usuário:").grid(row=1,column=0,sticky="e")
        self.ent_user = ttk.Entry(frm); self.ent_user.grid(row=1,column=1)
        ttk.Label(frm, text="Senha:").grid(row=2,column=0,sticky="e")
        self.ent_pass = ttk.Entry(frm, show="*"); self.ent_pass.grid(row=2,column=1)
        btns = ttk.Frame(self); btns.pack(pady=10)
        ttk.Button(btns, text="Cadastrar", command=self.do_register).grid(row=0,column=0,padx=5)
        ttk.Button(btns, text="Voltar", command=lambda: controller.show_frame("WelcomeScreen")).grid(row=0,column=1,padx=5)

    def do_register(self):
        name = self.ent_name.get().strip()
        u = self.ent_user.get().strip()
        p = self.ent_pass.get().strip()
        if not (name and u and p):
            messagebox.showwarning("Dados faltando", "Preencha todos os campos.")
            return
        try:
            self.controller.query("INSERT INTO users (username,password,is_admin,fullname) VALUES (?,?,?,?)", (u,p,0,name))
            messagebox.showinfo("Sucesso", "Cadastro realizado! Faça login.")
            self.controller.show_frame("LoginScreen")
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível cadastrar: {e}")

class ClientMenu(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        lbl = ttk.Label(self, text="Menu do Cliente", font=("Helvetica",18)); lbl.pack(pady=8)
        self.user_lbl = ttk.Label(self, text="")
        self.user_lbl.pack()
        btn_frame = ttk.Frame(self); btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Ver Jogos", command=lambda: controller.show_frame("GamesListScreen")).grid(row=0,column=0,padx=4)
        ttk.Button(btn_frame, text="Carrinho", command=lambda: controller.show_frame("CartScreen")).grid(row=0,column=1,padx=4)
        ttk.Button(btn_frame, text="Histórico de Compras", command=lambda: controller.show_frame("HistoryScreen")).grid(row=0,column=2,padx=4)
        ttk.Button(btn_frame, text="Sobre / Contato", command=lambda: controller.show_frame("AboutScreen")).grid(row=0,column=3,padx=4)
        ttk.Button(btn_frame, text="Logout", command=controller.logout).grid(row=1,column=1,pady=10)

    def on_show(self):
        if self.controller.current_user:
            self.user_lbl.config(text=f"Olá, {self.controller.current_user.get('fullname')}")
        else:
            self.user_lbl.config(text="Olá, visitante")

class AdminMenu(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Menu do Administrador", font=("Helvetica",18)).pack(pady=8)
        btns = ttk.Frame(self); btns.pack(pady=10)
        ttk.Button(btns, text="Gerenciar Jogos", command=lambda: controller.show_frame("ManageGamesScreen")).grid(row=0,column=0,padx=6)
        ttk.Button(btns, text="Gerenciar Usuários", command=lambda: controller.show_frame("ManageUsersScreen")).grid(row=0,column=1,padx=6)
        ttk.Button(btns, text="Ver Loja (cliente)", command=lambda: controller.show_frame("GamesListScreen")).grid(row=0,column=2,padx=6)
        ttk.Button(btns, text="Logout", command=controller.logout).grid(row=1,column=1,pady=10)

class GamesListScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        header = ttk.Frame(self)
        header.pack(fill="x")
        ttk.Label(header, text="Jogos Disponíveis", font=("Helvetica",16)).pack(side="left", padx=10, pady=8)
        self.search_var = tk.StringVar()
        ttk.Entry(header, textvariable=self.search_var).pack(side="left", padx=4)
        ttk.Button(header, text="Pesquisar", command=self.on_show).pack(side="left", padx=4)
        ttk.Button(header, text="Voltar", command=self.go_back).pack(side="right", padx=10)
        # content
        self.canvas = tk.Canvas(self)
        self.scroll = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.frame_inner = ttk.Frame(self.canvas)
        self.frame_inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_window((0,0), window=self.frame_inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll.pack(side="right", fill="y")

    def go_back(self):
        if self.controller.current_user:
            if self.controller.current_user.get("is_admin"):
                self.controller.show_frame("AdminMenu")
            else:
                self.controller.show_frame("ClientMenu")
        else:
            self.controller.show_frame("WelcomeScreen")

    def on_show(self):
        # clear
        for w in self.frame_inner.winfo_children():
            w.destroy()
        q = "SELECT id,title,price,stock,image FROM games"
        term = self.search_var.get().strip()
        params = ()
        if term:
            q += " WHERE title LIKE ?"
            params = (f"%{term}%",)
        rows = self.controller.query(q, params)
        for idx,row in enumerate(rows):
            gid, title, price, stock, image = row
            frm = ttk.Frame(self.frame_inner, relief="ridge", borderwidth=1, padding=6)
            frm.grid(row=idx, column=0, pady=6, padx=8, sticky="ew")
            img = load_image(image, size=(180,90))
            lbl_img = ttk.Label(frm, image=img); lbl_img.image = img
            lbl_img.grid(row=0,column=0,rowspan=3,padx=6)
            ttk.Label(frm, text=title, font=("Helvetica",12,"bold")).grid(row=0,column=1,sticky="w")
            ttk.Label(frm, text=f"R$ {price:.2f} - Estoque: {stock}").grid(row=1,column=1,sticky="w")
            btns = ttk.Frame(frm); btns.grid(row=2,column=1,sticky="w")
            ttk.Button(btns, text="Adicionar ao Carrinho", command=lambda g=gid: self.add_to_cart(g)).grid(row=0,column=0,padx=4)
            if self.controller.current_user and self.controller.current_user.get("is_admin"):
                ttk.Button(btns, text="Editar (Admin)", command=lambda g=gid: self.edit_game(g)).grid(row=0,column=1,padx=4)

    def add_to_cart(self, game_id):
        row = self.controller.query("SELECT id,title,price,stock FROM games WHERE id=?", (game_id,), one=True)
        if not row:
            messagebox.showerror("Erro", "Jogo não encontrado.")
            return
        gid, title, price, stock = row
        if stock <= 0:
            messagebox.showwarning("Sem estoque", "Este jogo está sem estoque.")
            return
        # check if already in cart
        for i,item in enumerate(self.controller.cart):
            if item[0] == gid:
                # increase qty
                self.controller.cart[i] = (gid, title, price, item[3]+1)
                messagebox.showinfo("Carrinho", f"Quantidade de {title} aumentada no carrinho.")
                return
        self.controller.cart.append((gid, title, price, 1))
        messagebox.showinfo("Carrinho", f"{title} adicionado ao carrinho.")

    def edit_game(self, gid):
        # set editing in ManageGames screen
        mg = self.controller.frames["ManageGamesScreen"]
        mg.load_game_for_edit(gid)
        self.controller.show_frame("ManageGamesScreen")

class CartScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Carrinho", font=("Helvetica",16)).pack(pady=8)
        self.tree = ttk.Treeview(self, columns=("title","price","qty","subtotal"), show="headings", height=10)
        for c in self.tree["columns"]:
            self.tree.heading(c, text=c.title())
        self.tree.pack(padx=10,pady=6)
        btns = ttk.Frame(self); btns.pack(pady=6)
        ttk.Button(btns, text="Remover Item", command=self.remove_item).grid(row=0,column=0,padx=4)
        ttk.Button(btns, text="Finalizar Compra", command=lambda: controller.show_frame("CheckoutScreen")).grid(row=0,column=1,padx=4)
        ttk.Button(btns, text="Voltar", command=self.go_back).grid(row=0,column=2,padx=4)

    def on_show(self):
        # refresh tree
        for r in self.tree.get_children():
            self.tree.delete(r)
        total = 0
        for item in self.controller.cart:
            gid, title, price, qty = item
            subtotal = price * qty
            total += subtotal
            self.tree.insert("", "end", iid=gid, values=(title,f"R$ {price:.2f}", qty, f"R$ {subtotal:.2f}"))
        # show total as last row
        self.total_lbl = ttk.Label(self, text=f"Total: R$ {total:.2f}", font=("Helvetica",12,"bold"))
        self.total_lbl.pack()

    def remove_item(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selecione", "Selecione um item para remover.")
            return
        gid = int(sel[0])
        self.controller.cart = [it for it in self.controller.cart if it[0] != gid]
        self.on_show()

    def go_back(self):
        self.controller.show_frame("GamesListScreen")

class CheckoutScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Finalizar Compra", font=("Helvetica",16)).pack(pady=8)
        self.info_lbl = ttk.Label(self, text="")
        self.info_lbl.pack()
        btns = ttk.Frame(self); btns.pack(pady=8)
        ttk.Button(btns, text="Confirmar Compra", command=self.confirm_purchase).grid(row=0,column=0,padx=6)
        ttk.Button(btns, text="Voltar ao Carrinho", command=lambda: controller.show_frame("CartScreen")).grid(row=0,column=1,padx=6)

    def on_show(self):
        if not self.controller.current_user:
            self.info_lbl.config(text="Você precisa estar logado para finalizar a compra.")
        elif not self.controller.cart:
            self.info_lbl.config(text="Carrinho vazio.")
        else:
            total = sum([item[2]*item[3] for item in self.controller.cart])
            self.info_lbl.config(text=f"Usuário: {self.controller.current_user.get('fullname')} - Total: R$ {total:.2f}")

    def confirm_purchase(self):
        if not self.controller.current_user:
            messagebox.showwarning("Login", "Faça login para confirmar a compra.")
            self.controller.show_frame("LoginScreen")
            return
        if not self.controller.cart:
            messagebox.showwarning("Carrinho", "Carrinho vazio.")
            return
        # reduce stock, create order
        total = sum([item[2]*item[3] for item in self.controller.cart])
        items_text = "; ".join([f"{it[1]} x{it[3]}" for it in self.controller.cart])
        uid = self.controller.current_user.get("id")
        now = datetime.datetime.now().isoformat()
        self.controller.query("INSERT INTO orders (user_id,items_text,total,created_at) VALUES (?,?,?,?)", (uid,items_text,total,now))
        # update stock
        for gid,_,_,qty in self.controller.cart:
            self.controller.query("UPDATE games SET stock = stock - ? WHERE id=?", (qty,gid))
        messagebox.showinfo("Compra", "Compra efetuada com sucesso!")
        self.controller.cart = []
        self.controller.show_frame("HistoryScreen")

class HistoryScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Histórico de Compras", font=("Helvetica",16)).pack(pady=8)
        self.lst = tk.Listbox(self, width=100, height=20)
        self.lst.pack(padx=10,pady=6)
        ttk.Button(self, text="Voltar", command=self.go_back).pack(pady=6)

    def on_show(self):
        self.lst.delete(0, "end")
        if not self.controller.current_user:
            self.lst.insert("end", "Faça login para ver seu histórico.")
            return
        uid = self.controller.current_user.get("id")
        rows = self.controller.query("SELECT items_text,total,created_at FROM orders WHERE user_id=? ORDER BY created_at DESC", (uid,))
        if not rows:
            self.lst.insert("end", "Nenhuma compra encontrada.")
            return
        for r in rows:
            self.lst.insert("end", f"{r[2]} - {r[0]} - Total: R$ {r[1]:.2f}")

    def go_back(self):
        if self.controller.current_user and self.controller.current_user.get("is_admin"):
            self.controller.show_frame("AdminMenu")
        elif self.controller.current_user:
            self.controller.show_frame("ClientMenu")
        else:
            self.controller.show_frame("WelcomeScreen")

class ManageGamesScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Gerenciar Jogos (Admin)", font=("Helvetica",16)).pack(pady=8)
        btns = ttk.Frame(self); btns.pack(pady=6)
        ttk.Button(btns, text="Novo Jogo", command=self.new_game).grid(row=0,column=0,padx=6)
        ttk.Button(btns, text="Atualizar Lista", command=self.on_show).grid(row=0,column=1,padx=6)
        ttk.Button(btns, text="Voltar", command=lambda: controller.show_frame("AdminMenu")).grid(row=0,column=2,padx=6)
        # tree
        self.tree = ttk.Treeview(self, columns=("title","price","stock"), show="headings", height=12)
        for c in self.tree["columns"]:
            self.tree.heading(c, text=c.title())
        self.tree.pack(padx=10,pady=6)
        edit_frame = ttk.Frame(self); edit_frame.pack(pady=6, fill="x")
        ttk.Label(edit_frame, text="Título:").grid(row=0,column=0)
        self.ent_title = ttk.Entry(edit_frame, width=30); self.ent_title.grid(row=0,column=1)
        ttk.Label(edit_frame, text="Preço:").grid(row=1,column=0)
        self.ent_price = ttk.Entry(edit_frame); self.ent_price.grid(row=1,column=1)
        ttk.Label(edit_frame, text="Estoque:").grid(row=2,column=0)
        self.ent_stock = ttk.Entry(edit_frame); self.ent_stock.grid(row=2,column=1)
        ttk.Label(edit_frame, text="Imagem:").grid(row=3,column=0)
        self.img_path_var = tk.StringVar()
        ttk.Entry(edit_frame, textvariable=self.img_path_var, width=30).grid(row=3,column=1)
        ttk.Button(edit_frame, text="Procurar...", command=self.browse_image).grid(row=3,column=2,padx=4)
        btns2 = ttk.Frame(edit_frame); btns2.grid(row=4,column=1,pady=6)
        ttk.Button(btns2, text="Salvar/Atualizar", command=self.save_game).grid(row=0,column=0,padx=4)
        ttk.Button(btns2, text="Remover Selecionado", command=self.remove_selected).grid(row=0,column=1,padx=4)
        self.editing_id = None

    def on_show(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        rows = self.controller.query("SELECT id,title,price,stock FROM games")
        for r in rows:
            self.tree.insert("", "end", iid=r[0], values=(r[1],f"R$ {r[2]:.2f}", r[3]))

    def new_game(self):
        self.editing_id = None
        self.ent_title.delete(0,"end"); self.ent_price.delete(0,"end"); self.ent_stock.delete(0,"end"); self.img_path_var.set("")

    def browse_image(self):
        p = filedialog.askopenfilename(filetypes=[("PNG/JPG","*.png;*.jpg;*.jpeg")])
        if p:
            # copy to images folder
            dest = IMAGES_DIR / Path(p).name
            try:
                from shutil import copyfile
                copyfile(p, dest)
                self.img_path_var.set(str(dest))
            except Exception as e:
                messagebox.showerror("Erro", f"Não foi possível copiar a imagem: {e}")

    def save_game(self):
        title = self.ent_title.get().strip()
        try:
            price = float(self.ent_price.get())
        except:
            messagebox.showwarning("Dados", "Preço inválido.")
            return
        try:
            stock = int(self.ent_stock.get())
        except:
            messagebox.showwarning("Dados", "Estoque inválido.")
            return
        image = self.img_path_var.get().strip() or ""
        if self.editing_id:
            self.controller.query("UPDATE games SET title=?,price=?,stock=?,image=? WHERE id=?",
                                  (title,price,stock,image,self.editing_id))
            messagebox.showinfo("Atualizado", "Jogo atualizado com sucesso.")
        else:
            self.controller.query("INSERT INTO games (title,price,stock,image) VALUES (?,?,?,?)", (title,price,stock,image))
            messagebox.showinfo("Criado", "Jogo criado com sucesso.")
        self.on_show()

    def remove_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selecione", "Selecione um jogo para remover.")
            return
        gid = int(sel[0])
        self.controller.query("DELETE FROM games WHERE id=?", (gid,))
        self.on_show()

    def load_game_for_edit(self, gid):
        row = self.controller.query("SELECT id,title,price,stock,image FROM games WHERE id=?", (gid,), one=True)
        if not row:
            messagebox.showerror("Erro", "Jogo não encontrado.")
            return
        self.editing_id = row[0]
        self.ent_title.delete(0,"end"); self.ent_title.insert(0,row[1])
        self.ent_price.delete(0,"end"); self.ent_price.insert(0,str(row[2]))
        self.ent_stock.delete(0,"end"); self.ent_stock.insert(0,str(row[3]))
        if row[4]:
            self.img_path_var.set(row[4])

class ManageUsersScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        ttk.Label(self, text="Gerenciar Usuários (Admin)", font=("Helvetica",16)).pack(pady=8)
        btns = ttk.Frame(self); btns.pack(pady=6)
        ttk.Button(btns, text="Atualizar Lista", command=self.on_show).grid(row=0,column=0,padx=6)
        ttk.Button(btns, text="Voltar", command=lambda: controller.show_frame("AdminMenu")).grid(row=0,column=1,padx=6)
        self.tree = ttk.Treeview(self, columns=("username","fullname","is_admin"), show="headings", height=12)
        for c in self.tree["columns"]:
            self.tree.heading(c, text=c.title())
        self.tree.pack(padx=10,pady=6)
        btns2 = ttk.Frame(self); btns2.pack(pady=6)
        ttk.Button(btns2, text="Tornar Admin", command=self.make_admin).grid(row=0,column=0,padx=4)
        ttk.Button(btns2, text="Remover Usuário", command=self.remove_user).grid(row=0,column=1,padx=4)

    def on_show(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        rows = self.controller.query("SELECT id,username,fullname,is_admin FROM users")
        for r in rows:
            self.tree.insert("", "end", iid=r[0], values=(r[1], r[2] or "", "Sim" if r[3] else "Não"))

    def make_admin(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selecione", "Selecione um usuário.")
            return
        uid = int(sel[0])
        self.controller.query("UPDATE users SET is_admin=1 WHERE id=?", (uid,))
        self.on_show()

    def remove_user(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Selecione", "Selecione um usuário.")
            return
        uid = int(sel[0])
        # prevent deleting admin self accidentally
        if self.controller.current_user and self.controller.current_user.get("id")==uid:
            messagebox.showwarning("Impossível", "Você não pode remover seu próprio usuário.")
            return
        self.controller.query("DELETE FROM users WHERE id=?", (uid,))
        self.on_show()

class AboutScreen(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        ttk.Label(self, text="Sobre / Contato", font=("Helvetica",16)).pack(pady=8)
        # logo
        logo_path = IMAGES_DIR / "logo.png"
        self.logo_img = load_image(logo_path, size=(360,180))
        ttk.Label(self, image=self.logo_img).pack()
        ttk.Label(self, text="ProzziGames\nContato: contato@prozzigames.example\nVersão: 1.0").pack(pady=8)
        ttk.Button(self, text="Voltar", command=self.go_back).pack(pady=6)

    def go_back(self):
        if self.controller.current_user:
            if self.controller.current_user.get("is_admin"):
                self.controller.show_frame("AdminMenu")
            else:
                self.controller.show_frame("ClientMenu")
        else:
            self.controller.show_frame("WelcomeScreen")

# ---------- Run ----------
def main():
    init_db()
    app = App()
    app.mainloop()

if __name__ == "__main__":
    main()
